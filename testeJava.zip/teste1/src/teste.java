//Teste nice do Java
public class teste {
    
    public static void main(String[] args ){
    //Isso vai aparecer na entrada do Hello world
    String txt = "Hello World"; String txt2 ="\"Hello World\""; String txt3="Hello \nWorld"; 
    System.out.println("TEXTO 1: \n"+txt);
    System.out.println("\nTEXTO 2: \n"+txt2);
    System.out.println("\nTEXTO 3: \n"+txt3);
    }
}
