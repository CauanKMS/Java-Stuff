//Teste nice 2
public class teste2 {
    
    public static void main(String[] args){
    //Comeco do Programa
    int num = 16;
    
    if(num==13){ 
        System.out.println("O num eh "+num);}
    else{
        System.out.println("O num NAO eh 13.");
    }
    }
}
